package com.nitheesh.certificate.renewalServiceImpl;

import org.springframework.stereotype.Service;

import com.nitheesh.certificate.Payload.CertificateDetails;
import com.nitheesh.certificate.Payload.CertificateResponse;
import com.nitheesh.certificate.renewalService.CertificationRenewalService;

@Service
public class CertificateRenewalServiceImpl implements CertificationRenewalService {

	@Override
	public CertificateResponse renewalCertificate(CertificateDetails certificateDetails) {
		// TODO Auto-generated method stub
		return null;
	}

}
