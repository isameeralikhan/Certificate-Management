package com.nitheesh.certificate.renewalService;

import com.nitheesh.certificate.Payload.CertificateDetails;
import com.nitheesh.certificate.Payload.CertificateResponse;

public interface CertificationRenewalService {
	
	public CertificateResponse renewalCertificate(CertificateDetails certificateDetails);

}
