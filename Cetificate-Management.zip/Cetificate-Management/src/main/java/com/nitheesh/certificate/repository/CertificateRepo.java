package com.nitheesh.certificate.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nitheesh.certificate.entity.CertificateData;

public interface CertificateRepo extends JpaRepository<CertificateData,String> {

}
