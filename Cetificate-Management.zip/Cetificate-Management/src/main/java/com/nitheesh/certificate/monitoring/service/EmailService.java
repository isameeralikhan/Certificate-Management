package com.nitheesh.certificate.monitoring.service;

public interface EmailService {
	
	
	public void sendEmail(String email,String body,String subject);

}
