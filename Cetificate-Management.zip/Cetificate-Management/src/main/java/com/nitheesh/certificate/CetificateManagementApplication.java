package com.nitheesh.certificate;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.nitheesh.certificate.monitoring.service.EmailService;

@SpringBootApplication
public class CetificateManagementApplication implements CommandLineRunner {
	@Autowired
	private EmailService emailService;
	
	public static void main(String[] args) throws IOException, CertificateException {
		SpringApplication.run(CetificateManagementApplication.class, args);	
		
//		CertificateFactory fac = CertificateFactory.getInstance("X509");
//		
//		
//		
//        FileInputStream stream=new FileInputStream("/Users/mandadinitheesh/eclipse-workspace/Cetificate-Management/certificate/c1.crt");
//        
//		
//        X509Certificate cert = (X509Certificate) fac.generateCertificate(stream);
//        
//        System.out.println("type is "+cert.getType());
//   
//		System.out.println("From: " + cert.getNotBefore());
//		System.out.println("Until: " + cert.getNotAfter());
//		
//		String string = cert.getIssuerX500Principal().toString();  String resultString="";
//		
//		System.out.println(string);
//		
//		String array[]=string.split(",");
//		
//		String string2 = Arrays.stream(array).filter((s)->s.contains("EMAILADDRESS")).findFirst().get();
//		System.out.println(string2.substring(13));
		
//		int indexOf = string.indexOf("EMAILADDRESS");
//		System.out.println(indexOf);
        
		//System.out.println(cert.getIssuerX500Principal());

		
	}

	@Override
	public void run(String... args) throws Exception {
		
		
		//emailService.sendEmail("nitheesh.19bcn7095@vitap.ac.in","please renew your certificate as it is expiring with in seven days","about certification renewal");
		
		SimpleDateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
		
		Calendar cal = Calendar.getInstance();
		Date today = cal.getTime();
		System.out.println(dateFormat.format(today));
		cal.add(Calendar.DAY_OF_WEEK, 2); // to get previous year add -1
		Date nextYear = cal.getTime();
		System.out.println(dateFormat.format(nextYear));
		
	}

}
