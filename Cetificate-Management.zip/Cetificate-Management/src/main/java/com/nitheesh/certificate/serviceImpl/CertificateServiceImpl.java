package com.nitheesh.certificate.serviceImpl;

import java.io.IOException;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Date;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.nitheesh.certificate.KeyPairService.KeyPairGeneratorService;
import com.nitheesh.certificate.Payload.CertificateDetails;
import com.nitheesh.certificate.Payload.CertificateResponse;
import com.nitheesh.certificate.fileService.KeyService;
import com.nitheesh.certificate.service.CertificateDaoService;
import com.nitheesh.certificate.service.CetificateService;

@Service
public class CertificateServiceImpl implements CetificateService {
	
	
	// key service to store the private key in a .key file..
	
	@Autowired
	private KeyService keyService;
	
	@Autowired
	private KeyPairGeneratorService keyPairGeneratorService;
	
	@Autowired
	private CertificateDaoService certificateDaoService;
	
	@Value("${certificate.selfsignedKey.filepath}")
	private String selfSignedkeyfilename;
	
	@Value("{certificate.cacertificatekey.filepath}")
	private String cafileName;
	
	@Value("${certificate.unsignedcertificatekey.filepath}")
	private String unsignedKeyFileName;
	
	@Value("${certicate.signedcertificatekey.filepath}")
	private String signedKeyFilename;
	
	

	@Override
	public X509Certificate generateSelfSignedCertificate(CertificateDetails details) throws OperatorCreationException, NoSuchAlgorithmException, CertificateException, IOException {
		
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
            keyPairGenerator.initialize(2048);
            KeyPair keyPair = keyPairGenerator.generateKeyPair();
      
            
            String name=String.format("CN=%s, O=%s, OU=%s, C=%s, L=%s, ST=%s, emailAddress=%s",details.getCommonName(),details.getOrganization(),details.getPrganizationalInput(),details.getCountry(),details.getLocality(),details.getState(),details.getEmailAddress());

            X500Name subjectName = new X500Name(name);

            BigInteger serialNumber = BigInteger.valueOf(System.currentTimeMillis());
            
            //current date...

            Date startDate = new Date();
            
            // valid upto 0ne year..
            
            Date endDate = new Date(startDate.getTime() + 365 * 24 * 60 * 60 * 1000); // 1 year validity
            
            SubjectPublicKeyInfo subPubKeyInfo =  SubjectPublicKeyInfo.getInstance(keyPair.getPublic().getEncoded());
            
            // certificate builder...
            
            X509v3CertificateBuilder certificateBuilder = new X509v3CertificateBuilder(
                    subjectName,
                    serialNumber,
                    startDate,
                    endDate,
                    new X500Name("CN=SelfSigned"),
                    subPubKeyInfo
            );
            
            ContentSigner contentSigner = new JcaContentSignerBuilder("SHA256WithRSA")
                    .build(keyPair.getPrivate());

            X509Certificate selfSignedCertificate = new JcaX509CertificateConverter()
                    .getCertificate(certificateBuilder.build(contentSigner));
           
            // storing the key to a file..
            keyService.addKeyToFile(keyPair.getPrivate(),selfSignedkeyfilename);
            
		return selfSignedCertificate;
				
}
	
	// genearting signed certificate....
	

	@Override
	public CertificateResponse generateSignedCertificate(CertificateDetails details) throws OperatorCreationException, CertificateException, IOException, NoSuchAlgorithmException {
		
		KeyPair SignedkeyPair=keyPairGeneratorService.generateKetPair();
	
		
		KeyPair caKeyPair=keyPairGeneratorService.generateKetPair();
		
		
		String name=String.format("CN=%s, O=%s, OU=%s, C=%s, L=%s, ST=%s, emailAddress=%s",details.getCommonName(),details.getOrganization(),details.getPrganizationalInput(),details.getCountry(),details.getLocality(),details.getState(),details.getEmailAddress());
		
		//X509Certificate caCertificate=generaCertificate(name, caKeyPair, "CN=CA",caKeyPair.getPublic(),cafileName);
		
		X509Certificate Signedcertificate=generaCertificate(name,caKeyPair, "CN=Signed",SignedkeyPair.getPublic(),signedKeyFilename);
		
		String filename=details.getCommonName().concat("-certificate");
		
		CertificateResponse response = certificateDaoService.saveCertificate(Signedcertificate,filename,SignedkeyPair.getPublic(),caKeyPair.getPrivate());
		
		return response ;
	}

	
	
	
	
	//genearating ca certificate..
	

	@Override
	public CertificateResponse generateCaCertificate(CertificateDetails details) throws NoSuchAlgorithmException, OperatorCreationException, CertificateException, IOException {
		
		KeyPair keyPair=keyPairGeneratorService.generateKetPair();
		
		String name=String.format("CN=%s, O=%s, OU=%s, C=%s, L=%s, ST=%s, emailAddress=%s",details.getCommonName(),details.getOrganization(),details.getPrganizationalInput(),details.getCountry(),details.getLocality(),details.getState(),details.getEmailAddress());
		
		
		X509Certificate CaCertificate=generaCertificate(name, keyPair,"CN=CA",keyPair.getPublic(),cafileName);
		
        String filename=details.getCommonName().concat("-certificate");
		
		CertificateResponse response = certificateDaoService.saveCertificate(CaCertificate,filename,keyPair.getPublic(),keyPair.getPrivate());
		
		
		return response;
	}

	
	// generating unsigned certificate...

	@Override
	public CertificateResponse generateUnsignedCertificate(CertificateDetails details) throws NoSuchAlgorithmException, OperatorCreationException, CertificateException, IOException {
KeyPair keyPair=keyPairGeneratorService.generateKetPair();
		
		String name=String.format("CN=%s, O=%s, OU=%s, C=%s, L=%s, ST=%s, emailAddress=%s",details.getCommonName(),details.getOrganization(),details.getPrganizationalInput(),details.getCountry(),details.getLocality(),details.getState(),details.getEmailAddress());
		
		X509Certificate unsignedCertificate=generaCertificate(name, keyPair,"CN=Unsigned",keyPair.getPublic(),unsignedKeyFileName);
		
String filename=details.getCommonName().concat("-certificate");
		
		CertificateResponse response = certificateDaoService.saveCertificate(unsignedCertificate,filename,keyPair.getPublic(),keyPair.getPrivate());
		
		
		return response;
	}
	
	
	
	// method to generate the certificate ...
	
	
	public X509Certificate generaCertificate(String name,KeyPair keyPair,String subjectDN,PublicKey key,String filename) throws OperatorCreationException, CertificateException, IOException {
		
		 X500Name subjectName = new X500Name(name);

         BigInteger serialNumber = BigInteger.valueOf(System.currentTimeMillis());
		
		 Date startDate = new Date();
         
         // valid upto 0ne year..
         
         Date endDate = new Date(startDate.getTime() + 365 * 24 * 60 * 60 * 1000); // 1 year validity
         
         SubjectPublicKeyInfo subPubKeyInfo =  SubjectPublicKeyInfo.getInstance(key.getEncoded());
         
         // certificate builder...
         
         X509v3CertificateBuilder certificateBuilder = new X509v3CertificateBuilder(
                 subjectName,
                 serialNumber,
                 startDate,
                 endDate,
                 new X500Name(subjectDN),
                 subPubKeyInfo
         );
         
         
         
         ContentSigner contentSigner = new JcaContentSignerBuilder("SHA256WithRSA")
                 .build(keyPair.getPrivate());

         X509Certificate Certificate = new JcaX509CertificateConverter()
                 .getCertificate(certificateBuilder.build(contentSigner));
        
         // storing the key to a file..
         //keyService.addKeyToFile(keyPair.getPrivate(),filename);
         
		return Certificate;
	}
	
	
	
	
	
}
