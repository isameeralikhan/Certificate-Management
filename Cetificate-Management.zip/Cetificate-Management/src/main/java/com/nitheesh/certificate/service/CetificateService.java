package com.nitheesh.certificate.service;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import org.bouncycastle.operator.OperatorCreationException;

import com.nitheesh.certificate.Payload.CertificateDetails;
import com.nitheesh.certificate.Payload.CertificateResponse;

public interface CetificateService {
	
	
	public X509Certificate generateSelfSignedCertificate(CertificateDetails details) throws OperatorCreationException, NoSuchAlgorithmException, CertificateException, IOException;

	public CertificateResponse generateSignedCertificate(CertificateDetails details) throws OperatorCreationException, CertificateException, IOException, NoSuchAlgorithmException;
	
	public CertificateResponse generateCaCertificate(CertificateDetails details) throws NoSuchAlgorithmException, OperatorCreationException, CertificateException, IOException;
	
	public CertificateResponse generateUnsignedCertificate(CertificateDetails details) throws NoSuchAlgorithmException, OperatorCreationException, CertificateException, IOException;
	
}
