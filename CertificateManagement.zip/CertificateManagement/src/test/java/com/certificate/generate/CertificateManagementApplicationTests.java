package com.certificate.generate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CertificateManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
