package com.certificate.generate.certificates;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.springframework.stereotype.Service;

import com.certificate.generate.client.Client;
import com.certificate.generate.save.KeySave;

import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.time.Instant;
import java.util.Date;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;


@Service
public class GenerateSelfSignedCertificate {
	
	private final BouncyCastleProvider bouncyCastleProvider;

    public GenerateSelfSignedCertificate(BouncyCastleProvider bouncyCastleProvider) {
		this.bouncyCastleProvider = bouncyCastleProvider;
    }
    
    public X509Certificate generateCertificate(Client response) throws Exception {
        Security.addProvider(bouncyCastleProvider);
        
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
        keyPairGenerator.initialize(2048, new SecureRandom());
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        KeySave.saveInFile(keyPair.getPrivate(), "./privateKeys/selfsigned-private-key.pem");
        X509Certificate cert = generateSelfSignedCertificate(keyPair, response);
        
        return cert;
    }

    private X509Certificate generateSelfSignedCertificate(KeyPair keyPair, Client response) throws Exception {
        Date startDate = Date.from(Instant.now());
        Date endDate = Date.from(Instant.now().plusSeconds(20 * 24 * 60 * 60)); // 1 year validity

        X509v3CertificateBuilder certBuilder = new X509v3CertificateBuilder(
                new X500Name(response.toString()),
                BigInteger.valueOf(System.currentTimeMillis()),
                startDate,
                endDate,
                new X500Name(response.toString()),
                SubjectPublicKeyInfo.getInstance(keyPair.getPublic().getEncoded()) // Use BouncyCastle's SubjectPublicKeyInfo
        );

        ContentSigner contentSigner = new JcaContentSignerBuilder("SHA256WithRSA").build(keyPair.getPrivate());

        return new JcaX509CertificateConverter().getCertificate(certBuilder.build(contentSigner)); // Use JcaX509CertificateConverter
    }
}
