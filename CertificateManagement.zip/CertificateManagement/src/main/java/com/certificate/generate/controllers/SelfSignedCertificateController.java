package com.certificate.generate.controllers;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.certificate.generate.certificates.GenerateSelfSignedCertificate;
import com.certificate.generate.client.Client;
import com.certificate.generate.save.SaveCertificate;
import com.certificate.generate.saveToDB.CertificateService;

import java.security.cert.X509Certificate;
import java.util.Base64;

@RestController
@RequestMapping("/api/self-signed")
public class SelfSignedCertificateController {

    private final GenerateSelfSignedCertificate certificateGenerator;

    public SelfSignedCertificateController(GenerateSelfSignedCertificate certificateGenerator) {
        this.certificateGenerator = certificateGenerator;
    }

    @PostMapping("/generate")
    public String generateCertificate(@RequestBody Client response) {
        try {
            X509Certificate certificate = certificateGenerator.generateCertificate(response);
            SaveCertificate.toFile(certificate, "./certificates/self-signed-cert.crt");
            CertificateService certificateService = new CertificateService();
            byte[] certificateData = certificate.getEncoded();

            // Base64 encode the certificate bytes
            String base64Certificate = Base64.getEncoder().encodeToString(certificateData);

            // Wrap the base64 encoded certificate in PEM format
            StringBuilder pemCertificate = new StringBuilder();
            pemCertificate.append("-----BEGIN CERTIFICATE-----\n");
            pemCertificate.append(base64Certificate).append("\n");
            pemCertificate.append("-----END CERTIFICATE-----\n");
			certificateService.saveCertificateToDB(pemCertificate.toString());
            return "Self-signed certificate and private key generated and stored.";
        } catch (Exception e) {
            return "Error generating certificate: " + e.getMessage() + "/n" + e.getStackTrace();
        }
    }
}
