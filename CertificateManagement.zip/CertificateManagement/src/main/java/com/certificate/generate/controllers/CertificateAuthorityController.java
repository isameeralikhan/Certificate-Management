package com.certificate.generate.controllers;

import java.security.cert.X509Certificate;
import java.util.Base64;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.certificate.generate.certificates.GenerateCACertificate;
import com.certificate.generate.client.Client;
import com.certificate.generate.save.SaveCertificate;
import com.certificate.generate.saveToDB.CertificateService;

@RestController
@RequestMapping("/api/ca")
public class CertificateAuthorityController {

    private final GenerateCACertificate caService;

    public CertificateAuthorityController(GenerateCACertificate caService) {
        this.caService = caService;
    }

    @PostMapping("/generate")
    public String generateCACertificate(@RequestBody Client response) {
        try {
        	X509Certificate certificate = caService.generateAndStoreCACertificate(response);
            SaveCertificate.toFile(certificate, "./certificates/ca-cert.crt");
            CertificateService certificateService = new CertificateService();
            byte[] certificateData = certificate.getEncoded();

            // Base64 encode the certificate bytes
            String base64Certificate = Base64.getEncoder().encodeToString(certificateData);

            // Wrap the base64 encoded certificate in PEM format
            StringBuilder pemCertificate = new StringBuilder();
            pemCertificate.append("-----BEGIN CERTIFICATE-----\n");
            pemCertificate.append(base64Certificate).append("\n");
            pemCertificate.append("-----END CERTIFICATE-----\n");
			certificateService.saveCertificateToDB(pemCertificate.toString());
            return "CA certificate and private key generated and stored.";
        } catch (Exception e) {
            return "Error generating CA certificate: " + e.getMessage();
        }
    }
}
