package com.certificate.generate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CertificateManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(CertificateManagementApplication.class, args);
		
//		try {
//            GenerateCertificate certificateGenerator = new GenerateCertificate();
//            X509Certificate certificate = certificateGenerator.generateCertificate();
//            // Save or use the generated certificate as needed
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
	}

}