package com.certificate.generate.client;

public class Client {
	String name;
	String organization;
	String organizationalUnit;
	String country;
	String locality;
	String stateOrProvince;
	String email;
	public Client() {
		
	}
	public Client(String name, String organization, String organizationalUnit, String country, String locality,
			String stateOrProvince, String email) {
		super();
		this.name = name;
		this.organization = organization;
		this.organizationalUnit = organizationalUnit;
		this.country = country;
		this.locality = locality;
		this.stateOrProvince = stateOrProvince;
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOrganization() {
		return organization;
	}
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	public String getOrganizationalUnit() {
		return organizationalUnit;
	}
	public void setOrganizationalUnit(String organizationalUnit) {
		this.organizationalUnit = organizationalUnit;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getStateOrProvince() {
		return stateOrProvince;
	}
	public void setStateOrProvince(String stateOrProvince) {
		this.stateOrProvince = stateOrProvince;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "CN=" + name + ", O=" + organization + ", OU=" + organizationalUnit
				+ ", C=" + country + ", L=" + locality + ", ST=" + stateOrProvince
				+ ", emailAddress=" + email;
	}
	
}
