package com.certificate.generate.controllers;

import java.security.cert.X509Certificate;
import java.util.Base64;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.certificate.generate.certificates.GenerateSignedCertificate;
import com.certificate.generate.client.Client;
import com.certificate.generate.save.SaveCertificate;
import com.certificate.generate.saveToDB.CertificateService;

@RestController
@RequestMapping("/api/signed")
public class SignedCertificateController {
	
	private final GenerateSignedCertificate certificateGenerator;

    public SignedCertificateController(GenerateSignedCertificate certificateGenerator) {
        this.certificateGenerator = certificateGenerator;
    }
	
    @PostMapping("/generate")
    public String generateSignedCertificate(@RequestBody Client clientInfo) {
        try {
            X509Certificate certificate = certificateGenerator.generateSignedCertificate(clientInfo);
            SaveCertificate.toFile(certificate, "./certificates/signed-cert.crt");
            byte[] certificateData = certificate.getEncoded();

            // Base64 encode the certificate bytes
            String base64Certificate = Base64.getEncoder().encodeToString(certificateData);

            // Wrap the base64 encoded certificate in PEM format
            StringBuilder pemCertificate = new StringBuilder();
            pemCertificate.append("-----BEGIN CERTIFICATE-----\n");
            pemCertificate.append(base64Certificate).append("\n");
            pemCertificate.append("-----END CERTIFICATE-----\n");
			CertificateService certificateService = new CertificateService();
			certificateService.saveCertificateToDB(pemCertificate.toString());
            return "Signed certificate and private key generated and stored.";
            
        } catch (Exception e) {
            throw new RuntimeException("Error generating signed certificate: " + e.getMessage());
        }
    }
}