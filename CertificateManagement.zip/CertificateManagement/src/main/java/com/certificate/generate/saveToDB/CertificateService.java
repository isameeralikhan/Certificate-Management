package com.certificate.generate.saveToDB;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.certificate.generate.repo.CertificateRepository;

@Service
public class CertificateService {

    @Autowired
	CertificateRepository certificateRepository;

    public void saveCertificateToDB(String cert) throws Exception {
        
        // Convert the certificate to bytes and save it
        certificateRepository.save(cert);
    }
}