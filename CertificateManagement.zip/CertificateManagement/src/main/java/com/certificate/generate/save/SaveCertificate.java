package com.certificate.generate.save;

import java.io.FileOutputStream;
import java.security.cert.X509Certificate;
import org.springframework.stereotype.Service;

@Service
public class SaveCertificate {
	public static void toFile(X509Certificate certificate, String fileName) throws Exception {
        try (FileOutputStream fos = new FileOutputStream(fileName)) {
            fos.write(certificate.getEncoded());
        }
    }
}
