package com.certificate.generate.certificates;

import java.io.FileInputStream;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509ExtensionUtils;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.springframework.stereotype.Service;

import com.certificate.generate.client.Client;

@Service
public class GenerateSignedCertificate {

        private String caCertificatePath = "./certificates/ca-cert.crt";
        private String caPrivateKeyPath = "./privateKeys/ca-private-key.pem";
        
        public X509Certificate generateSignedCertificate(Client response) throws Exception {
            X509Certificate caCertificate = loadCertificate(caCertificatePath);
            PrivateKey caPrivateKey = loadPrivateKey(caPrivateKeyPath);
            PublicKey publicKey = caCertificate.getPublicKey();

            X500Name issuer = new X500Name(caCertificate.getIssuerX500Principal().getName());
            BigInteger serialNumber = new BigInteger(64, new SecureRandom());

            Date startDate = new Date();
            Date endDate = new Date(startDate.getTime() + 365 * 24 * 60 * 60 * 1000); // 1 year validity

            X500Name subject = new X500Name("CN="+response.getName());

            JcaX509v3CertificateBuilder certBuilder = new JcaX509v3CertificateBuilder(
                issuer,
                serialNumber,
                startDate,
                endDate,
                subject,
                publicKey
            );

            JcaX509ExtensionUtils extUtils = new JcaX509ExtensionUtils();
            certBuilder.addExtension(org.bouncycastle.asn1.x509.Extension.subjectKeyIdentifier, false, extUtils.createSubjectKeyIdentifier(publicKey));
            certBuilder.addExtension(org.bouncycastle.asn1.x509.Extension.authorityKeyIdentifier, false, extUtils.createAuthorityKeyIdentifier(caCertificate.getPublicKey()));

            ContentSigner contentSigner = new JcaContentSignerBuilder("SHA256WithRSAEncryption").build(caPrivateKey);

            X509CertificateHolder certHolder = certBuilder.build(contentSigner);
            return new JcaX509CertificateConverter().getCertificate(certHolder);
        }
        
	    private static X509Certificate loadCertificate(String certificatePath) throws Exception {
	        CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
	        try (FileInputStream inputStream = new FileInputStream(certificatePath)) {
	            return (X509Certificate) certificateFactory.generateCertificate(inputStream);
	        }
	    }
	
	    private static PrivateKey loadPrivateKey(String privateKeyPath) throws Exception {
	        byte[] privateKeyBytes = Files.readAllBytes(Paths.get(privateKeyPath));
	        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
	        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privateKeyBytes);
	        return keyFactory.generatePrivate(keySpec);
	    }
}
