package com.certificate.generate.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.certificate.generate.entity.CertificateEntity;

public interface CertificateRepository extends JpaRepository<CertificateEntity, Long> {

	void save(String cert);
	
}
