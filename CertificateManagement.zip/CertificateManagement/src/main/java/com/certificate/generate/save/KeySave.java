package com.certificate.generate.save;

import java.io.FileOutputStream;
import java.security.PrivateKey;

import org.springframework.stereotype.Service;

@Service
public class KeySave {

	public static void saveInFile(PrivateKey private1, String filepath) throws Exception {
		// TODO Auto-generated method stub
		try (FileOutputStream fos = new FileOutputStream(filepath)) {
            fos.write(private1.getEncoded());
        }
	}

}
