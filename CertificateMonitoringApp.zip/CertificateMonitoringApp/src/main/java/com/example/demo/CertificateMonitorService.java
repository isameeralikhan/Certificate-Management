package com.example.demo;
import java.io.FileInputStream;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Date;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class CertificateMonitorService {
    private final KafkaProducerService kafkaProducerService;
    private final String certificateFilePath = "F:\\eclipse-workspace\\CertificateManagement\\certificates\\self-signed-cert.crt";

    public CertificateMonitorService(KafkaProducerService kafkaProducerService) {
        this.kafkaProducerService = kafkaProducerService;
    }

    @Scheduled(cron = "0 * 9 * * ?") // Run every day at midnight
    public void checkCertificateExpiration() {
        try {
        	CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
            FileInputStream inputStream = new FileInputStream(certificateFilePath);
            X509Certificate certificate = (X509Certificate) certificateFactory.generateCertificate(inputStream);
            inputStream.close();
            
            Date expirationDate = certificate.getNotAfter();
            Date currentDate = new Date();

            long daysUntilExpiration = (expirationDate.getTime() - currentDate.getTime()) / (1000 * 60 * 60 * 24);

            if (daysUntilExpiration <= 30) {
                String message = "Certificate will expire in " + daysUntilExpiration + " days.";
                kafkaProducerService.sendNotification(message);
            }
        } catch (Exception e) {
            // Handle exceptions (e.g., file not found, certificate parsing error)
        	System.out.println(e.getMessage()+" "+e.getStackTrace());
        }
    }
}
