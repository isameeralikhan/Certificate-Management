package com.example.demo;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class EmailConsumerService {

    @KafkaListener(topics = "email-topic", groupId = "email-consumer-group")
    public void listen(String emailMessage) {
        // Send the email using your email sending logic here
        System.out.println("Received email message: " + emailMessage);
        // Implement email sending logic here
    }
}
